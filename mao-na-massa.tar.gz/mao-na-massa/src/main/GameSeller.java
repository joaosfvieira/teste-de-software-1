package main;

import exception.ArgumentoInvalidoException;

public class GameSeller {
	
	public static int JOGO_TABULEIRO = 1;
	public static int JOGO_STREAM = 2;
	public static int JOGO_DVD = 3;
	
	public double calculaPreco (int tipoJogo, double valor) throws ArgumentoInvalidoException{
		
		if(tipoJogo > 3 || tipoJogo < 1 || valor < 0)
			throw new ArgumentoInvalidoException();
		
		try {	
			if(tipoJogo == 3) {
				if(valor < 100)
					return valor + 30;
				return valor + 20;
			}
			
			if(tipoJogo == 1) {
				if(valor < 200) 
					return valor + 30;
			}
			
			return valor;
		} catch(Exception e) {
			throw new ArgumentoInvalidoException();
		}
		
	}
	
	
}