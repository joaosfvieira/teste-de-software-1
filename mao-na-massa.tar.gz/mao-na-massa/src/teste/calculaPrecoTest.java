package teste;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import exception.ArgumentoInvalidoException;
import main.GameSeller;

@RunWith(Parameterized.class)
public class calculaPrecoTest {
	
	GameSeller gameSeller;
	
	@Before
	public void init() {
		gameSeller = new GameSeller();
	}
	@Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {
                 {0, 50, 50}, {5, 100, 130}, {1, -100, -130},{ 1, 50, 80 }, { 1, 250, 250 }, { 2, 50, 50 }, { 2, 500, 500 }, { 3, 50, 80 }, { 3, 100, 120 }, { 1, 0, 30 }  
           });
    }

    @Parameter(0) 
    public int inputTipo;

    @Parameter(1)
    public double inputValor;
    
    @Parameter(2)
    public double expected;
	
	
	@Test
	public void test() {
		try {
			assertEquals(expected, gameSeller.calculaPreco(inputTipo, inputValor), 0);
		} catch(ArgumentoInvalidoException e) {
			e.printStackTrace();
		}
	}

}
