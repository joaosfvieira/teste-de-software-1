import static org.junit.Assert.*;

import org.junit.Test;

public class teste {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
