package exception;

public class ArgumentoInvalidoException extends Exception {

}
